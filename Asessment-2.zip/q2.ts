var  a = prompt("enter the choice:");
var choice = '';
switch (a) {
    case 'A':
        choice = "Excellent";
        alert(choice);
        break;
    case 'B':
        choice = "Good";
        alert(choice);
        break;
    case 'C':
        choice = "Fair";
        alert(choice);
        break;
    case 'D':
        choice = "Poor";
        alert(choice);
        break;
    default: {
        alert("Invalid Input");
        break;
    }
}
